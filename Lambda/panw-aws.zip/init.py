"""
/*****************************************************************************
 * Copyright (c) 2016, Palo Alto Networks. All rights reserved.              *
 *                                                                           *
 * This Software is the property of Palo Alto Networks. The Software and all *
 * accompanying documentation are copyrighted.                               *
 *****************************************************************************/

Copyright 2016 Palo Alto Networks

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

  http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
"""

import boto3
import logging
import json
import httplib
import xml.etree.ElementTree as et
import time
from urlparse import urlparse
from contextlib import closing
import ssl
import urllib2
import decimal
import uuid
import sys
import urllib
import hashlib
import base64
from boto3.dynamodb.conditions import Key, Attr

sys.path.append('lib/')
import pan.asglib as lib

s3 = boto3.client('s3')
ec2 = boto3.resource('ec2')
ec2_client = ec2.meta.client
lambda_client = boto3.client('lambda')
asg = boto3.client('autoscaling')

logger = logging.getLogger()
logger.setLevel(logging.INFO)

valid_panfw_productcode_ids = {
    "6njl1pau431dv1qxipg63mvah": "VMLIC_BYOL",
    "ezf1psxb2kioq7658vhqcsd8l": "VM100_BND1",
    "aq69x88mwu3gsgzl9cnp2jrs" : "VM100_BND2",
    "6mydlutex4aol2trr2g7q65iv": "VM200_BND1",
    "1a8cei9n1136q07w76k0hsryu": "VM200_BND2",
    "6kxdw3bbmdeda3o6i1ggqt4km": "VM300_BND1",
    "806j2of0qy5osgjjixq9gqc6g": "VM300_BND2",
    "drl1fmzuqe2xzolduol1a44lk": "VM1000_BND1",
    "2yxza6dt6eedvvs80ohu1ae63": "VM1000_BND2",
    #AWS IC product codes
    "3bgub3avj7bew2l8odml3cxdx": "VMLIC_IC_BYOL",
    "atpzu21quydhsik27m2f0u8f" : "VM300_IC_BND1",
    "13w0cso64r7c4rralytfju3p6": "VM300_IC_BND2"
}


def send_response(event, context, responseStatus):
    """
    Method to send a response back to the CFT process.

    :param event:
    :param context:
    :param responseStatus:
    :return:
    """
    r=responseStatus.split(":")
    print(r)
    rs=str(r[0])
    reason=""
    if len(r) > 1:
        reason = str(r[1])
    else:
        reason = 'See the details in CloudWatch Log Stream.'
    print('send_response() to stack -- responseStatus: ' + str(rs) + ' Reason: ' + str(reason))
    response = {
                'Status': str(rs),
                'Reason': str(reason),
                'StackId': event['StackId'],
                'RequestId': event['RequestId'],
                'LogicalResourceId': event['LogicalResourceId'],
                'PhysicalResourceId': event['LogicalResourceId']
               }
    logger.info('RESPONSE: ' + json.dumps(response))
    parsed_url = urlparse(event['ResponseURL'])
    if (parsed_url.hostname == ''):
        logger.info('[ERROR]: Parsed URL is invalid...')
        return 'false'

    logger.info('[INFO]: Sending Response...')
    try:
        with closing(httplib.HTTPSConnection(parsed_url.hostname)) as connection:
            connection.request("PUT", parsed_url.path+"?"+parsed_url.query, json.dumps(response))
            response = connection.getresponse()
            if response.status != 200:
                logger.info('[ERROR]: Received non 200 response when sending response to cloudformation')
                logger.info('[RESPONSE]: ' + response.msg)
                return 'false'
            else:
                logger.info('[INFO]: Got good response')

    except:
        logger.info('[ERROR]: Got ERROR in sending response...')
        return 'false'
    finally:

        connection.close()
        return 'true'

def read_s3_object(bucket, key):
    """
    Method to read data from and S3 bucket.

    .. note:: This method is used to read bootstrap
              information, in order to license and
              configure the firewall.

    :param bucket:
    :param key:
    :return:
    """
    # Get the object from the event and show its content type
    key = urllib.unquote_plus(key).decode('utf8')
    try:
        response = s3.get_object(Bucket=bucket, Key=key)
        print("CONTENT TYPE: " + response['ContentType'])
        contents=response['Body'].read()
        #print('Body: ' + str(contents))
        return str(contents)
    except Exception as e:
        print(e)
        print('Error getting object {} from bucket {}. Make sure they exist.'.format(key, bucket))
        return None

def delete_resources(event):
    """
    Method to handle the delete of resources when the
    CFT stack is deleted.

    :param event:
    :return:
    """
    logger.info('Deleteing resources...')
    stackname = event['ResourceProperties']['StackName']
    region=event['ResourceProperties']['Region']

    r = event['ResourceProperties']
    logger.info('Dump all the parameters')
    logger.info(r)

    BootstrapS3Bucket = r['BootstrapS3Bucket']
    ELBTargetGroupName = r['ELBTargetGroupName']
    SubnetIDTrust = r['SubnetIDTrust']
    RouteTableIDTrust = r['RouteTableIDTrust']    
    VPCSecurityGroup=r['VPCSecurityGroup']
    VpcId = r['VpcId']

    SubnetIDTrust=str(lib.fix_unicode(SubnetIDTrust))
    SubnetIDTrust=lib.fix_subnets(SubnetIDTrust)
    
    c=read_s3_object(BootstrapS3Bucket, "config/init-cfg.txt")
    dict = lib.get_values_from_init_cfg(c)
    logger.info('Init CFG bootstrap file Panorama settings: ')
    logger.info(dict)
    pip=dict['panorama-server']
    pdg=dict['dgname']
    ptpl=dict['tplname']    



    asg_name = stackname + '-PANW-Firewall-ASG'

    logger.info('Remove ASG: ' + asg_name)

    try:
        logger.info('Disable metrics collection and Set Min and Desired Capacity to 0 for ASG: ' + asg_name)
        asg.disable_metrics_collection(AutoScalingGroupName=asg_name)
        asg.update_auto_scaling_group(AutoScalingGroupName=asg_name, MinSize=0, DesiredCapacity=0)
    except Exception as e:
         logger.info('Could not disable_metrics_collection and Set Min/Desired Capacity to 0 for ASG. Reason below')
         logger.info("[RESPONSE]: {}".format(e))

    response=asg.describe_auto_scaling_groups(AutoScalingGroupNames=[asg_name])
  
    # Initiate removal of all EC2 instances associated to ASG
    found = False
    for i in response['AutoScalingGroups']:
        for ec2i in i['Instances']:
            found = True
            logger.info('Terminating instance: ' + ec2i['InstanceId'] + ' HealthStatus: ' + ec2i['HealthStatus'])
            logger.info(ec2i)

            #lib.release_eip(stackname, ec2i['InstanceId'])  ?????

            try:
                ec2_client.terminate_instances(InstanceIds=[ec2i['InstanceId']])
            except Exception as e:
                logger.warning("[Terminate Instance in ASG]: {}".format(e))
   
    logger.info('Removing Life Cycle Hooks for ASG: ' + asg_name)
    hookname=asg_name + '-life-cycle-launch'
    try:
        asg.delete_lifecycle_hook(LifecycleHookName=hookname, AutoScalingGroupName=asg_name)
    except Exception as e:
        logger.info("[ASG life-cycle Hook Launch]: {}".format(e))
    hookname=asg_name + '-life-cycle-terminate'
    try:
        asg.delete_lifecycle_hook(LifecycleHookName=hookname, AutoScalingGroupName=asg_name)
    except Exception as e:
        logger.info("[ASG life-cycle Hook Terminate]: {}".format(e))

    force = False
    logger.info('Deleting ASG : ' + asg_name)
    for i in range(1,90):
        if i >= 5:
            force=True
        try:
            if force == True:
                asg.delete_auto_scaling_group(AutoScalingGroupName=asg_name, ForceDelete=True)
            else:
                asg.delete_auto_scaling_group(AutoScalingGroupName=asg_name)
        except Exception as e:
            logger.info('Could not remove ASG. Reason below')
            logger.info("[ASG DELETE]: {}".format(e))
   
        time.sleep(1)

    return True

def update_resources(event):
    """
    Method to handle any updates to the CFT templates.

    :param event: CFT input parameters
    :return: None
    """
    stackname = event['ResourceProperties']['StackName']
    logger.info('Updating resources for stackname: ' + stackname)

    Arn=event['StackId']
    r = event['ResourceProperties']
    oldr = event['OldResourceProperties']
    logger.info('Dump all the new parameters')
    logger.info(r)
    logger.info('Dump all the OLD parameters')
    logger.info(oldr)

    LambdaExecutionRole = r['LambdaExecutionRole']
    LambdaS3Bucket=r['LambdaS3Bucket']
    PanS3KeyTpl=r['PanS3KeyTpl']
    elb_name=r['ELBName']
    ELBTargetGroupName=r['ELBTargetGroupName']
    sgv= r['VPCSecurityGroup']
    BootstrapS3Bucket = r['BootstrapS3Bucket']
    ASGNotifierRole=str(r['ASGNotifierRole'])
    LambdaENISNSTopic=str(r['LambdaENISNSTopic'])
    NumberOfFWs = r['NumberOfFWs']
    NumberOfFWs = int(NumberOfFWs)

    SubnetIDTrust = r['SubnetIDTrust']
    RouteTableIDTrust = r['RouteTableIDTrust']    
    SubnetIDUntrust = r['SubnetIDUntrust']
    SubnetIDMgmt = r['SubnetIDMgmt']

    RouteTableIDTrust=str(lib.fix_unicode(RouteTableIDTrust))
    RouteTableIDTrust=lib.fix_subnets(RouteTableIDTrust)  
    SubnetIDTrust=str(lib.fix_unicode(SubnetIDTrust))
    SubnetIDTrust=lib.fix_subnets(SubnetIDTrust)
    SubnetIDUntrust=str(lib.fix_unicode(SubnetIDUntrust))
    SubnetIDUntrust=lib.fix_subnets(SubnetIDUntrust)
    SubnetIDMgmt=str(lib.fix_unicode(SubnetIDMgmt))
    SubnetIDMgmt=lib.fix_subnets(SubnetIDMgmt)

    #create_resources(event)

    logger.info('-------------------------------------------------------------------------------')
    logger.info('Lambda Template S3 Bucket: ' + LambdaS3Bucket + ' S3Key is : ' + PanS3KeyTpl)
    logger.info('-------------------------------------------------------------------------------')

    lambda_func_name= r['FwInit']
    try:
        lambda_client.update_function_code(FunctionName=lambda_func_name, S3Bucket=LambdaS3Bucket, S3Key=PanS3KeyTpl)
        logger.info('Updated FwInit Lambda Function Code Successfully')
    except Exception as e:
        logger.error('Update Resource for FwInit Lambda Failed')
        logger.error("[Update Resource FwInit Lambda]: {}".format(e))
        return False

    lambda_func_name= r['InitLambda']
    try:
        lambda_client.update_function_code(FunctionName=lambda_func_name, S3Bucket=LambdaS3Bucket, S3Key=PanS3KeyTpl)
        logger.info('Updated Init Lambda Function Code Successfully')
    except Exception as e:
        logger.error('Update Resource for Init Lambda Failed')
        logger.error("[Update Resource Init Lambda]: {}".format(e))
        return False

    #fw_azs = lib.getAzs(SubnetIDTrust)
    #for i in fw_azs:
    search = stackname + '-PANW-Firewall-ASG'
    #search = lib.get_asg_name(stackname, ELBTargetGroupName)
    response=asg.describe_auto_scaling_groups(AutoScalingGroupNames=[search])
    if len(response['AutoScalingGroups']) == 0:
        logger.error('ASG is not found')
        return False 
    if len(response['AutoScalingGroups']) > 1:
        logger.error('Multiple ASGs found')
        return False
    asg_response = response['AutoScalingGroups'][0]

    logger.info('Update Resource: ASG Name: ' + asg_response['AutoScalingGroupName'])
    asg_name = asg_response['AutoScalingGroupName']
    try:
        asg.update_auto_scaling_group(AutoScalingGroupName=asg_name,
                                      MinSize=NumberOfFWs, MaxSize=NumberOfFWs,
                                      DesiredCapacity=NumberOfFWs)
    except Exception as e:
        logger.error("[Update ASG failed]: {}".format(e))
        return False

    logger.info('Done Updating Resources...')
    return True
 
    """
    logger.info('Updating Life Cycle Hook for ASG: ' + asg_name)
    hookname = asg_name + '-life-cycle-launch'
    #mgmt = lib.choose_subnet(SubnetIDMgmt, i)
    #untrust = lib.choose_subnet(SubnetIDUntrust, i)
    #trust = lib.choose_subnet(SubnetIDTrust, i)

    metadata = {
            'MGMT': mgmt, 'UNTRUST': untrust, 'TRUST': trust, 'KeyPANWFirewall': KeyPANWFirewall,
            'SGM': MgmtSecurityGroup, 'SGT': TrustSecurityGroup
    }

    try:
        asg.put_lifecycle_hook(LifecycleHookName=hookname, AutoScalingGroupName=asg_name,
                                   LifecycleTransition="autoscaling:EC2_INSTANCE_LAUNCHING",
                                   RoleARN=ASGNotifierRole, NotificationTargetARN=LambdaENISNSTopic,
                                   DefaultResult="ABANDON", HeartbeatTimeout=300,
                                   NotificationMetadata=json.dumps(metadata))
    except Exception as e:
        logger.error("[ASG LifeCycle Hook Launch. ROLLBACK]: {}".format(e))
        return False

    hookname = asg_name + '-life-cycle-terminate'
    try:
        asg.put_lifecycle_hook(LifecycleHookName=hookname, AutoScalingGroupName=asg_name,
                                   LifecycleTransition="autoscaling:EC2_INSTANCE_TERMINATING",
                                   RoleARN=ASGNotifierRole, NotificationTargetARN=LambdaENISNSTopic,
                                   DefaultResult="CONTINUE", HeartbeatTimeout=300,
                                   NotificationMetadata=json.dumps(metadata))
    except Exception as e:
        logger.error("[ASG LifeCycle Hook Terminate. ROLLBACK]: {}".format(e))
    
    logger.info('Done Updating Resources...')
    return
    """

def validate_ami_id(event):
    """
       Validate that the AMI-ID provided is a valid
       PAN FW AMI.
       :param event: The CFT event params
       :return: bool
    """
    resource_props = event['ResourceProperties']
    ami_id = resource_props['ImageID']
    valid_ami = False
    valid_state = False

    try:
        image_info = ec2_client.describe_images(
                ImageIds=[ami_id]
        )
    except Exception as e:
        logger.info("Exception occured while retrieving AMI ID information: {}".format(e))
        return False

    logger.info('describe_images:response: {}'.format(image_info))

    ami_images = image_info['Images']
    for image in ami_images:
        product_codes = image['ProductCodes']
        for code in product_codes:
            product_code_id = code.get("ProductCodeId", None)
            if product_code_id in valid_panfw_productcode_ids.keys():
                valid_ami = True
                break

        if image['State'] == 'available':
            valid_state = True

    if valid_ami and valid_state:
        return True 

def create_resources(event):
    """
    This method is called from the lambda handler entry point.
    The following actions are performed:
        - validate the AMI-ID
        - deploys the ```sched_evt1``` lambda function.

    :param event:
    :return: None
    """
    stackname = event['ResourceProperties']['StackName']
    logger.info('Creating resources for stackname: ' + stackname)

    r = event['ResourceProperties']
    logger.info('Dump all the parameters')
    logger.info(r)
    VpcId = r['VpcId']
    FWInstanceType = r['FWInstanceType']
    BootstrapS3Bucket = r['BootstrapS3Bucket']
    SubnetIDTrust = r['SubnetIDTrust']
    RouteTableIDTrust = r['RouteTableIDTrust']    
    SubnetIDUntrust = r['SubnetIDUntrust']
    SubnetIDMgmt = r['SubnetIDMgmt']
    TrustSecurityGroup = r['TrustSecurityGroup']
    UntrustSecurityGroup = r['UntrustSecurityGroup']
    MgmtSecurityGroup = r['MgmtSecurityGroup']
    VPCSecurityGroup= r['VPCSecurityGroup']
    ELBName = r['ELBName']
    ELBTargetGroupName = r['ELBTargetGroupName']
    SSHLocation = r['SSHLocation']
    ImageID = r['ImageID']
    KeyName = r['KeyName']
    NumberOfFWs = r['NumberOfFWs']
    NumberOfFWs = int(NumberOfFWs)
    LambdaENISNSTopic = r['LambdaENISNSTopic']
    Region = r['Region']
    LambdaExecutionRole = r['LambdaExecutionRole']
    PanS3KeyTpl=r['PanS3KeyTpl']
    FirewallBootstrapRole = r['FirewallBootstrapRole']
    ASGNotifierRole= r['ASGNotifierRole']
    ASGNotifierRolePolicy= r['ASGNotifierRolePolicy']
    SubnetIDNATGW=r['SubnetIDNATGW']
    RouteTableIDTrust=str(lib.fix_unicode(RouteTableIDTrust))
    RouteTableIDTrust=lib.fix_subnets(RouteTableIDTrust)    
    SubnetIDTrust=str(lib.fix_unicode(SubnetIDTrust))
    SubnetIDTrust=lib.fix_subnets(SubnetIDTrust)
    SubnetIDUntrust=str(lib.fix_unicode(SubnetIDUntrust))
    SubnetIDUntrust=lib.fix_subnets(SubnetIDUntrust)
    SubnetIDMgmt=str(lib.fix_unicode(SubnetIDMgmt))
    SubnetIDMgmt=lib.fix_subnets(SubnetIDMgmt)
    SubnetIDNATGW=str(lib.fix_unicode(SubnetIDNATGW))
    SubnetIDNATGW=lib.fix_subnets(SubnetIDNATGW)
    FWLaunchTemplate = r['FWLaunchTemplate']
    PublicLoadBalancerTargetGroupARNs = r['PublicLoadBalancerTargetGroupARNs']

    r = event['ResourceProperties']
    lambda_exec_role_name=r['LambdaExecutionRole']

    LambdaS3Bucket=r['LambdaS3Bucket']

    logger.info('-------------------------------------------------------------------------------')
    logger.info('Lambda Template S3 Bucket: ' + LambdaS3Bucket + ' S3Key is : ' + PanS3KeyTpl)
    logger.info('-------------------------------------------------------------------------------')

    asg_name = stackname + '-PANW-Firewall-ASG'
    logger.info('Creating Auto-Scaling Group with name: ' + asg_name)
    tags={'ResourceId': asg_name, 'ResourceType': 'auto-scaling-group', 'Key': 'Name', 'Value': asg_name, 'PropagateAtLaunch':True}
    logger.info(' Subnet Untrust List: ' + SubnetIDUntrust)
    try:
        response=asg.create_auto_scaling_group(AutoScalingGroupName=asg_name,
                    LaunchTemplate={'LaunchTemplateId': FWLaunchTemplate},
                MinSize=NumberOfFWs, MaxSize=NumberOfFWs, DesiredCapacity=NumberOfFWs,
                TargetGroupARNs=[PublicLoadBalancerTargetGroupARNs],
                VPCZoneIdentifier=SubnetIDUntrust,
                Tags=[tags],
                HealthCheckGracePeriod=900)
    except Exception as e:
         logger.error("[ASG create error]: {}".format(e))
         return False


    logger.info('Creating Life Cycle Hook for ASG: ' + asg_name)
    hookname= asg_name + '-life-cycle-launch'

    metadata = {
                'MGMT': SubnetIDMgmt, 'UNTRUST': SubnetIDUntrust, 'TRUST': SubnetIDTrust, 
                'SGM': MgmtSecurityGroup, 'SGT': TrustSecurityGroup 
    }
  
    try:
        asg.put_lifecycle_hook(LifecycleHookName=hookname, AutoScalingGroupName=asg_name,
            LifecycleTransition="autoscaling:EC2_INSTANCE_LAUNCHING",
            RoleARN=ASGNotifierRole, NotificationTargetARN=LambdaENISNSTopic,
            DefaultResult="ABANDON", HeartbeatTimeout=300,
            NotificationMetadata=json.dumps(metadata))
    except Exception as e:
        logger.error("[ASG LifeCycle Hook Launch. ROLLBACK]: {}".format(e))
        return False

    hookname=asg_name + '-life-cycle-terminate'
    try:
        asg.put_lifecycle_hook(LifecycleHookName=hookname, AutoScalingGroupName=asg_name,
            LifecycleTransition="autoscaling:EC2_INSTANCE_TERMINATING",
            RoleARN=ASGNotifierRole, NotificationTargetARN=LambdaENISNSTopic,
            DefaultResult="CONTINUE", HeartbeatTimeout=300,
            NotificationMetadata=json.dumps(metadata))
    except Exception as e:
        logger.error("[ASG LifeCycle Hook Terminate. ROLLBACK]: {}".format(e))
        return False

    return True

def lambda_handler(event, context):
    """
        .. note:: This function is the entry point for the ```init``` Lambda function.
           This function performs the following actions:

           - invokes ```create | delete | update_resources()``` based on the action
                         required.
           - creates the ```sched_evt1``` lambda function
                        and configures the same.

           - validates that the PAN FW AMI-ID specified as input
                        is valid and supported.

        :param event: Encodes all the input variables to the lambda function, when
                      the function is invoked.
                      Essentially AWS Lambda uses this parameter to pass in event
                      data to the handler function.
        :type event: dict

        :param context: AWS Lambda uses this parameter to provide runtime information to your handler.
        :type context: LambdaContext

        :return: None
    """
    logger.info('got event{}'.format(event))

    r = event['ResourceProperties']

    lfunc=r['InitLambda']
    lresponse=lambda_client.get_function(FunctionName=lfunc)
    logger.info(json.dumps(lresponse))
    region = r['Region']
    stackname = r['StackName']
    SubnetIDNATGW = r['SubnetIDNATGW']

    ami_id = event['ResourceProperties']['ImageID']
    status="SUCCESS"
    #if len(VpcAzs) != int(NumberOfAZs):
    #	logger.info("number of az entered does not match the Az list entered.")
   # 	send_response(event, context, "FAILURE")
    try:
        if event['RequestType'] == 'Delete':
            delete_resources(event)
            logger.info('[INFO]: Sending delete response to S3 URL for stack deletion to proceed')
        elif event['RequestType'] == 'Create':
            try:
                logger.info('Validate Ami-Id: {}'.format(ami_id))
                if not validate_ami_id(event):
                    # Check to ensure that the AMI-ID specified is valid.
                    send_response(event, context, "FAILURE: We do not support AMI-ID: {}".format(ami_id))
                    return
            except Exception as e:
                logger.error("Failed to determine validity of the AMI specified: {}".format(e))
                send_response(event, context, "FAILURE: validating AMI-ID {}. Unable to proceed".format(ami_id))
                return

            logger.info('Successfully validated that the Ami is a valid PAN FW AMI')

            try:
                SubnetIDNATGW=str(lib.fix_unicode(SubnetIDNATGW))
                SubnetIDNATGW=lib.fix_subnets(SubnetIDNATGW)
                nlen=len(SubnetIDNATGW.split(','))
                print('Length of NATGW Subnets: ' + str(nlen))
                if nlen == 0:
                    logger.error('[ERROR]: Either Lambda or NATGW Subnets were not passed...')
                    send_response(event, context, "FAILURE:  NATGW Subnets were not passed")
                    return

                if nlen > 4:
                        logger.error('[ERROR]: NATGW Subnets are more than 4 AZs')
                        send_response(event, context, "FAILURE: NATGW Subnets are more than 4 AZs")
                        return
            except Exception as e:
                logger.error("[StackNameLenCheck]: {}".format(e))

            try:
                logger.info('Length of stackname is: ' + str(len(stackname)))
                if len(stackname) > 128:
                    logger.error('[ERROR]: We dont support Stack Name more than 128 characters long...')
                    send_response(event, context, "FAILURE: We dont support Stack Name more than 128 characters long")
                    return
            except Exception as e:
                logger.error("[StackNameLenCheck]: {}".format(e))
    
            create_resources(event)
            logger.info('[INFO]: Sending Create response to S3 URL for stack creation to proceed')
        elif event['RequestType'] == 'Update':
            update_resources(event)
            logger.info('[INFO]: Sending Update response to S3 URL for stack.')
    except Exception as e:
        logger.error('[ERROR]: Got ERROR in Init Lamnda handler...')
        logger.error("[Error in Init Lambda Handler]: {}".format(e))

    if (send_response(event, context, status)) == 'false':
        logger.info('[ERROR]: Got ERROR in sending response to S3 URL for custom resource...')
