"""
/*****************************************************************************
 * Copyright (c) 2016, Palo Alto Networks. All rights reserved.              *
 *                                                                           *
 * This Software is the property of Palo Alto Networks. The Software and all *
 * accompanying documentation are copyrighted.                               *
 *****************************************************************************/

Copyright 2016 Palo Alto Networks

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at
 
  http://www.apache.org/licenses/LICENSE-2.0
 
Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
"""

from __future__ import print_function
import boto3
import botocore
import json
import logging
import time
import uuid
import sys
import ssl

sys.path.append('lib/')
import pan.asglib as lib

mgmt=""
untrust=""
trust=""
sgm=""
sgu=""
sgt=""
asg_name=""
#elb_name=""

asg = boto3.client('autoscaling')
ec2 = boto3.resource('ec2')
ec2_client = ec2.meta.client

valid_panfw_productcode_byol = {
    "6njl1pau431dv1qxipg63mvah": "VMLIC_BYOL",
    #AWS IC product codes
    "3bgub3avj7bew2l8odml3cxdx": "VMLIC_IC_BYOL",
}

    

def remove_eni(message):
    """

    :param message:
    :return:
    """
    instanceId = message['EC2InstanceId']
    logger.info('Removing Network Interfaces for instanceId: ' + instanceId)
    
    # Detach all the ENIs first
    response=ec2_client.describe_network_interfaces(Filters=[{'Name': "attachment.instance-id", 'Values': [str(instanceId)]}])
    cnt = 0
    eni_ids=[]
    for i in response['NetworkInterfaces']:
        eniId=i['NetworkInterfaceId']
        Attachment=i['Attachment']
        aId=Attachment['AttachmentId']
        logger.info('Detaching Eni ID: ' + eniId + ' Desc: ' + i['Description'] + ' IP: ' + i['PrivateIpAddress'] + ' AZ: ' + i['AvailabilityZone'])
        logger.info('Detaching Attachment ID: ' + aId + ' DeviceIndex: ' +  str(Attachment['DeviceIndex']))
        if Attachment['DeviceIndex'] != 0:
            try:
                ec2_client.detach_network_interface(AttachmentId=aId)
                cnt = cnt + 1
                eni_ids.append(str(eniId))
            except Exception as e:
                logger.warning("[detach Eni]: {}".format(e))
                try:
                    ec2_client.delete_network_interface(NetworkInterfaceId=eniId)
                except Exception as e:
                    logger.warning("[delete Eni]: {}".format(e))

    if cnt == 0:
        logger.warning('No more ENIs for delete. Strange though')
        return
    
    logger.info('Delete ENIs PANW InstanceID: ' + str(instanceId) + ' ENI cnt: ' + str(cnt))
    logger.info('Delete ENIs: ' + str(eni_ids))

    # Now delete ENIs if they are in 'available' state
    fcnt = 0
    for timeout in range(0,25):
        if fcnt == cnt:
            logger.info('Finally Done with deleting all ENIs')
            return
        
        response=ec2_client.describe_network_interfaces(
                NetworkInterfaceIds=eni_ids,
                Filters=[{'Name': 'status', 'Values': ['available']}])
        
        for i in response['NetworkInterfaces']:
            id=i['NetworkInterfaceId']
            fcnt = fcnt + 1
            try:
                ec2_client.delete_network_interface(NetworkInterfaceId=id)
            except Exception as e:
                logger.error("[delete Eni after detach]: {}".format(e))
                
        time.sleep(5)
        
    response=ec2_client.describe_network_interfaces(NetworkInterfaceIds=eni_ids)
    for i in response['NetworkInterfaces']:
        logger.error('Timed out waiting for detach ENI. Final cnt: ' + str(fcnt) + ' vs ' + str(cnt))
        logger.error(i)

    logger.error('Return from remove_eni due to detach issue')                
    return

def count_eni(msg, instanceId):
    """

    :param msg:
    :param instanceId:
    :return:
    """
    response=ec2_client.describe_network_interfaces(Filters=[{'Name': "attachment.instance-id", 'Values': [str(instanceId)]}])
    #logger.info(response)
    cnt = 0
    for i in response['NetworkInterfaces']:
        cnt =  cnt + 1
    logger.info(msg + ' PANW InstanceID: ' + str(instanceId) + ' ENI cnt: ' + str(cnt))
    return cnt


def check_belongsto_az (list_subnet, az):
    """
    :param list_subnet
    :param az  
    :return: chosensubnet/None
    """
    list_len = len(list_subnet)
    for i in range(list_len):
        response = ec2_client.describe_subnets(SubnetIds=[list_subnet[i]])
        logger.info('Retrived response for subnet data{}'.format(response))
        for r in response['Subnets']:
            subnetaz= r['AvailabilityZone']
            if (subnetaz == az ):
                chosensubnet= r['SubnetId']
#                logger.info ("Found the required subnet for this instance :" +chosensubnet)
                return chosensubnet
    return None
    
def lambda_handler(event, context):
    """
    The entry point when this lambda function gets
    invoked.

    .. note:: The primary objective of this lambda funciton
              is to handle life-cycle hooks and to create / delete
              elastic network interfaces to assign / disassociate to / from
              instances.

    :param event: Encodes all the input variables to the lambda function, when
                      the function is invoked.
                      Essentially AWS Lambda uses this parameter to pass in event
                      data to the handler function.
    :param context: AWS Lambda uses this parameter to provide runtime information to your handler.
    :return: None
    """
    global asg_name
    global mgmt
    global untrust
    global trust
    global sgm
    global sgu
    global sgt
    global logger

    logger = logging.getLogger()
    logger.setLevel(logging.INFO)

    message = json.loads(event['Records'][0]['Sns']['Message'])
    logger.info('Message in the SNS is:')
    logger.info(message)

    #logger.info('got event{}'.format(event))
    
    strevent=str(event)
    
    if strevent.find("autoscaling:TEST_NOTIFICATION") >= 0:
        logger.info('Testing Notification SNS Message ')
        logger.info('ASG name is: ' + message['AutoScalingGroupName'])
        return 
    
    
    asg_name=message['AutoScalingGroupName']
    instanceId = message['EC2InstanceId']
    logger.info('instanceId: ' + instanceId)
    metadata = json.loads(message['NotificationMetadata'])

    mgmt=metadata['MGMT']
    untrust=metadata['UNTRUST']
    trust=metadata['TRUST']
    sgm=metadata['SGM']
    sgt=metadata['SGT']

    logger.info('LifecycleHookName1: ' + message['LifecycleHookName'])

    cnt = count_eni("INIT", instanceId)

    if strevent.find("autoscaling:EC2_INSTANCE_LAUNCHING") >= 0:
        logger.info('PANW EC2 Firewall Instance is launching')
        
    if strevent.find("autoscaling:EC2_INSTANCE_TERMINATING") >= 0:
        logger.info('PANW EC2 Firewall Instance is terminating')

        logger.info('Handle the cleanup of the ENI')
        count_eni("REMOVE", instanceId)

        done('true', context, message);
        return

    logger.info('Mgmt Subnet: ' + mgmt + ' Security-Group: ' + sgm)
    logger.info('Trust Subnet: ' + trust + ' Security-Group: ' + sgt)
    
    list_mgmt=mgmt.split(",")
    list_untrust=untrust.split(",")
    list_trust=trust.split(",")
    
    #get the az to which the instance belongs
    logger.info('The instance being considered is :' +instanceId)
    response=ec2_client.describe_instances(InstanceIds=[instanceId])
    logger.info('Retrived response{}'.format(response))
    for r in response['Reservations']:
        for i in r['Instances']:
            az= i['Placement']['AvailabilityZone']
            logger.info('The instance belongs to AvailabilityZone :' +az)    
    
    #get the subnets for corresponding az of the instance 
    mgmt = check_belongsto_az (list_mgmt, az)
    logger.info ("The management subnet for this instance is: " + mgmt )
    untrust = check_belongsto_az (list_untrust, az)
    logger.info ("The untrust subnet for this instance is: " + untrust )
    trust = check_belongsto_az (list_trust, az)
    logger.info ("The trust subnet for this instance is: " + trust )  
    
    #CreateEni for mgmt interface
    nif = ""
    err = createEni(mgmt, sgm, 1)
    if err == 'false':
        logger.info("Error: Eni creation failed\n")
        abandon(context, message)
        return

    #Wait for the ENI to be 'available'
    mgmt_eniId=eniId
    err = waitEniReady(eniId)
    if err == 'false':
        logger.info("ERROR: Failure waiting for ENI to be ready");
        abandon(context, message)
        return

    #Attach the network interface to the instance
    mgmt_instanceId = instanceId
    mgmt_eniId=eniId
    err = attachEni(instanceId, eniId, 1)
    if err == 'false':
        logger.info("ERROR: Failure attaching ENI to instance for eth1");
        removeEni(eniId)
        abandon(context, message)
        return
    else:
        logger.info("INFO: Success! Attached ENI to instance for eth1");

    #CreateEni for Trust Subnet
    nif = ""
    err = createEni(trust, sgt, 2)
    if err == 'false':
        logger.info("Error: Eni creation failed\n")

    logger.info(nif)
    #Wait for the ENI to be 'available'
    err = waitEniReady(eniId)
    if err == 'false':
        logger.info("ERROR: Failure waiting for ENI to be ready");
        abandon(context, message)
        return

    #Attach the network interface to the instance
    err = attachEni(instanceId, eniId, 2)
    if err == 'false':
        logger.info("ERROR: Failure attaching ENI to instance for eth2");
        removeEni(eniId)
        abandon(context, message)
        return
    else:
        logger.info("INFO: Success! Attached ENI to instance for eth2");

    count_eni("ADD", instanceId)
  
    done('true', context, message);
    return

def abandon(context, asg_message):
    """
    Method to send a response to the
    auto scale life cycle action.

    :param context:
    :param asg_message:
    :return:
    """
    result = "ABANDON";

    #call autoscaling
    try:
        asg.complete_lifecycle_action(
            AutoScalingGroupName = asg_message['AutoScalingGroupName'],
            LifecycleHookName = asg_message['LifecycleHookName'],
            LifecycleActionToken = asg_message['LifecycleActionToken'],
            LifecycleActionResult = result)
    except Exception as e:
        logger.error("[complete_lifecycle_action]: {}".format(e))

def done(success, context, asg_message):
    """
    Method to send a successful response to an
    ASG lifecycle action.

    :param success:
    :param context:
    :param asg_message:
    :return:
    """
    result = "CONTINUE";

    #call autoscaling
    try:
        asg.complete_lifecycle_action(
            AutoScalingGroupName = asg_message['AutoScalingGroupName'],
            LifecycleHookName = asg_message['LifecycleHookName'],
            LifecycleActionToken = asg_message['LifecycleActionToken'],
            LifecycleActionResult = result)
    except Exception as e:
        logger.error("[complete_lifecycle_action]: {}".format(e))
        return False

    return True
        
#Create a network interface, pass the Interface ID to callback
def createEni(subnetId, securityGroups, index):
    """
    Method to create and Elastic Network Interface
    :param subnetId:
    :param securityGroups:
    :param index:
    :return:
    """
    global nif
    global eniId
    
    desc=asg_name + '-eth' + str(index)
    logger.info('Creating ENI for Subnet: ' + subnetId)
    logger.info('Creating ENI for SG: ' + securityGroups)
    try:
        nif = ec2.create_network_interface(SubnetId=subnetId, Groups=[securityGroups], Description=desc)
    except botocore.exceptions.ClientError as error:
        logger.info("ERROR: ENI creation failed.\n");
        logger.info(error)
        return 'false'
    else:
        logger.info("INFO: ENI Created.\n");
        try:
            nif.modify_attribute(SourceDestCheck={'Value': False})
            nif.reload()
            response = nif.describe_attribute(Attribute='description')
            eniId = response['NetworkInterfaceId']
            logger.info('Eni-id for newly created ENI is: ' + str(eniId))
        except Exception as e:
            logger.error("[createEni modify attr, reload failed]: {}".format(e))
            logger.error('Deleting previously created ENI');
            logger.error(nif)
            logger.error('Nif id is: ' + str(nif.id))
            removeEni(nif.id)
            return 'false'
            
        return 'true'

def removeEni(eniId1):
    """
    Method to disassociate an ENI from an instance.
    :param eniId1:
    :return:
    """
    try:
        ec2_client.delete_network_interface(NetworkInterfaceId=eniId1)
    except Exception as e:
        logger.error("[removeEni]: {}".format(e))
        
    return

def waitEniReady(eniId):
    """
    Method to check if an ENI is ready
    :param eniId:
    :return:
    """
    try:
        waiter = ec2_client.get_waiter('network_interface_available')
        waiter.wait(NetworkInterfaceIds=[eniId], Filters= [{'Name' : 'status', 'Values': ['available']}])
    except botocore.exceptions.ClientError:
        logger.info("ERROR: ENI failed to reach desired state\n")
        return 'false'
    else:
       return 'true'


def attachEni(ec2Id, eniId, index):
    """
    Method to attach and ENI to an instance
    :param ec2Id:
    :param eniId:
    :param index:
    :return:
    """
    try:
        response=ec2_client.attach_network_interface(NetworkInterfaceId=eniId, InstanceId=ec2Id,DeviceIndex=index)
        aid=response['AttachmentId']
        ec2_client.modify_network_interface_attribute(NetworkInterfaceId=eniId,
                Attachment={ 'AttachmentId': aid, 'DeleteOnTermination': True})
    except Exception as e:
        logger.error("[attach/modify Eni]: {}".format(e))
        return 'false'

    else:
        logger.info('INFO: ENI attached EC2 instance for index: ' + str(index))
        return 'true'
